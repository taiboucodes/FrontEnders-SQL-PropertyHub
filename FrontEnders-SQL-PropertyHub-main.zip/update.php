<?php
session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("HTTP/1.1 403 Forbidden");
    exit("Forbidden");
}

// Database configuration
$host = "localhost";
$user = "pdelrossi1";
$pass = "pdelrossi1";
$dbname = "pdelrossi1";

// Establish database connection
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    header("HTTP/1.1 500 Internal Server Error");
    exit("Internal Server Error");
}
// Get property ID and other updated data from the POST request
$id = $_POST["id"];
$location = $_POST["location"];
$sqr_feet = $_POST["sqr_feet"];

// Perform the SQL update operation
$sql = "UPDATE properties SET location='$location', sqr_feet='$sqr_feet' WHERE id='$id'";
$result = mysqli_query($conn, $sql);

if ($result) {
    // Return a response indicating success
    header("HTTP/1.1 200 OK");
    exit("Property successfully updated");
} else {
    // Return a response indicating failure
    header("HTTP/1.1 500 Internal Server Error");
    exit("Internal Server Error");
}
// Close the database connection
mysqli_close($conn);
?>