<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', '1');

$host = "localhost";
$user = "pdelrossi1";
$pass = "pdelrossi1";
$dbname = "pdelrossi1";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["login"])) {
        // Login logic
        $input_user = $_POST["username"];
        $input_pass = $_POST["password"];

        // Validate login credentials against the database
        $sql_login = "SELECT * FROM users_new WHERE username='$input_user'";
        $result = $conn->query($sql_login);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $stored_pass = $row["password"];

            // Verify the hashed password
            if (password_verify($input_pass, $stored_pass)) {
                $_SESSION["loggedin"] = true;
                header("Location: index.html");
                exit;
            } else {
                echo "Invalid username or password.";
            }
        } else {
            echo "Invalid username or password.";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <p>Login if you have an account, or <a href="registration.php">click here to register</a>.</p>
    <form action="" method="post">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" name="login" value="Login">
    </form>
</body>
</html>
