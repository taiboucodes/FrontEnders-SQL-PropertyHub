<?php
$host = "localhost";
$user = "pdelrossi1";
$pass = "pdelrossi1";
$dbname = "pdelrossi1";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["register"])) {
        // Registration logic
        $input_user = $_POST["username"];
        $input_pass = $_POST["password"];
        $input_email = $_POST["email"];

        // Check if the username already exists
        $sql_check_user = "SELECT * FROM users_new WHERE username='$input_user'";
        $result_check_user = $conn->query($sql_check_user);

        if ($result_check_user->num_rows > 0) {
            echo "Username already exists. Please choose a different username.";
        } else {
            // Hash the password
            $hashed_pass = password_hash($input_pass, PASSWORD_DEFAULT);

            // Insert user into the database
            $sql_register = "INSERT INTO users_new (username, password, email) VALUES ('$input_user', '$hashed_pass', '$input_email')";
            if ($conn->query($sql_register) === TRUE) {
                // Redirect to login page after successful registration
                header("Location: login.php");
                exit;
            } else {
                echo "Error: " . $sql_register . "<br>" . $conn->error;
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
</head>
<body>
    <h2>Registration</h2>
    <p>New User? Register below.</p>
    <form action="" method="post">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        Email: <input type="email" name="email" required><br>
        <input type="submit" name="register" value="Register">
    </form>
</body>
</html>
